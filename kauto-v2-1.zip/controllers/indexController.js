const fs = require("fs");
const review = require("../models/reviewModel");
const car = require("../models/carModel");
const user = require("../models/userModel");
const store = require("../models/storeModel");
const appError = require("../utils/appErrors");
const catchAsync = require("../utils/catchAsync");
const nodemailer = require("nodemailer");
const slugify = require("slugify");

// ===== DATA

const cities = JSON.parse(fs.readFileSync(`${__dirname}/../json/cities.json`));
const brands = JSON.parse(fs.readFileSync(`${__dirname}/../json/cars.json`));
const types = JSON.parse(fs.readFileSync(`${__dirname}/../json/types.json`));
const propeties = JSON.parse(fs.readFileSync(`${__dirname}/../json/propeties.json`));
const boites = JSON.parse(fs.readFileSync(`${__dirname}/../json/boite.json`));
const carburant = JSON.parse(fs.readFileSync(`${__dirname}/../json/carburant.json`));

// =========================================== GET THE MAIN PAGE

exports.getIndex = catchAsync(async (req, res, next) => {
  var list = [];
  var cars = [];
  var stores = [];

  const cityStores = await store.find({ emailValide: "YES", "store.city.fr": req.ipInfo.city });
  const allStores = await store.find({ emailValide: "YES" });

  for (let j = 0; j < cityStores.length; j++) {
    var carCheap = await car.findOne({ store: cityStores[j]._id }).sort({ price: 1, remise: -1 }).populate("store", "store.location.coordinates");
    if (cars.length < 4) cars.push(carCheap);
    if (stores.length < 16) stores.push(cityStores[j]);
  }

  for (let i = 0; i < allStores.length; i++) {
    var item = {};
    var carCheap = await car.findOne({ store: allStores[i]._id }).sort({ price: 1, remise: -1 }).populate("store", "store.location.coordinates");
    var remise = carCheap.remise || 0;

    item.coordinates = carCheap.store.store.location.coordinates;
    item.id = carCheap._id;
    item.price = parseInt(carCheap.price - carCheap.price * (remise / 100));
    list.push(item);

    if (cars.length < 4 && !cars.includes(carCheap)) cars.push(carCheap);
    if (stores.length < 16 && !stores.includes(allStores[i])) stores.push(allStores[i]);
  }

  res.status(200).render("index", {
    title: "Kauto.ma | site gratuit de location des voitures",
    cities,
    brands,
    stores,
    cars,
    list,
    propeties,
  });
});

// ================================================ CAR DETAILS

exports.logout = (req, res, next) => {
  try {
    res.clearCookie("cookie");
    res.redirect("/");
  } catch (err) {
    next(err);
  }
};

// ================================================ CAR DETAILS

exports.carDetails = catchAsync(async (req, res, next) => {
  const carDetail = await car.findById(req.params.id).populate("store");

  if (!carDetail) {
    return next(new appError("Aucune voiture trouvée"), 404);
  }
  //   const reviews = await review.find({ which: req.params.id }).populate("from");

  res.status(200).render("carDetail", {
    title: `${carDetail.marque.fr} - ${carDetail.model.fr}`,
    propeties,
    carDetail,
  });
});

// ======================================================= SEARCH

var global;

exports.searchPage = catchAsync(async (req, res, next) => {
  if (global.ville.toString() != "/^/") {
    var stores = await store.find(
      {
        "store.city.fr": { $in: global.ville },
        "store.secteur.fr": { $in: global.secteur },
      },
      "_id"
    );
    stores.forEach((value, index) => {
      stores[index] = value._id + "";
    });
  }

  var cars = await car
    .find({
      "marque.fr": { $in: global.marque },
      "model.fr": { $in: global.modele },
      "carburant.fr": { $in: global.carburant },
      "boite.fr": { $in: global.boite },
      "climat.fr": { $in: global.climat },
      type: { $in: global.carburant },
      price: { $gte: global.min, $lte: global.max },
    })
    .populate("store");

  var ok = cars.slice(0);

  if (stores) {
    ok.forEach((value) => {
      var index = cars.indexOf(value);
      if (!stores.includes(value.store._id + "")) cars.splice(index, 1);
    });
  }

  var carsRecom = await car.find({}).limit(8);
  const mrq = global.marque.toString() === "/^/";

  res.status(200).render("resultat", {
    title: "Kauto.ma | meilleur site de location de voiture au Maroc",
    cars,
    carsRecom,
    propeties,
    types,
    brands,
    cities,
    boites,
    carburant,
    mrq,
    global,
  });
});

exports.searchCars = catchAsync(async (req, res, next) => {
  var link = "/res";

  for (const property in req.body) {
    if (req.body[property] != "all") {
      var item = JSON.parse(req.body[property]).fr;
      req.body[property] = [item];
      link += `/${slugify(item, { lower: true })}`;
    } else req.body[property] = [/^/];
  }

  req.body.type = [/^/];
  req.body.carburant = [/^/];
  req.body.boite = [/^/];
  req.body.climat = [/^/];
  req.body.max = 30000;
  req.body.min = 0;

  global = req.body;
  res.redirect(`${link}`);
});

exports.filter = catchAsync(async (req, res, next) => {
  var link = "/res";

  for (var property in req.body) {
    if (property != "min" && property != "max") {
      if (`${property.split("-")[0]}` in req.body) {
        req.body[property.split("-")[0]].push(property.split("-")[1]);
        delete req.body[property];
      } else {
        req.body[property.split("-")[0]] = new Array();
        req.body[property.split("-")[0]].push(property.split("-")[1]);
        delete req.body[property];
      }
    }
  }

  req.body.ville = global.ville;
  req.body.secteur = global.secteur;

  //   =========================================

  if (!req.body.marque) {
    req.body.marque = global.marque;
    req.body.modele = global.modele;
  } else req.body.modele = [/^/];

  if (!req.body.type) req.body.type = [/^/];
  if (!req.body.carburant) req.body.carburant = [/^/];
  if (!req.body.boite) req.body.boite = [/^/];
  if (!req.body.climat) req.body.climat = [/^/];

  //   =========================================

  if (req.body.ville.toString() != "/^/") link = link + "/" + slugify(req.body.ville.join(), { lower: true });
  if (req.body.secteur.toString() != "/^/") link = link + "/" + slugify(req.body.secteur.join(), { lower: true });
  if (req.body.marque.toString() != "/^/") link = link + "/" + slugify(req.body.marque.join("-"), { lower: true });
  if (req.body.type) link = link + "/" + slugify(req.body.type.join("-"), { lower: true });

  global = req.body;
  res.redirect(`${link}`);
});

// ================================================== LAW

exports.PrivacyPolicy = (req, res) => {
  res.status(200).render("PrivacyPolicy", {
    title: "Kauto.ma | Privacy Policy ",
  });
};

exports.termsandconditions = (req, res) => {
  res.status(200).render("termsandconditions", {
    title: "Kauto.ma | Terms And Conditions",
  });
};

exports.Desclaimer = (req, res) => {
  res.status(200).render("Desclaimer", {
    title: "Kauto.ma | Desclaimer",
  });
};

exports.howitworks = (req, res) => {
  res.status(200).render("howitworks", {
    title: "Kauto.ma | Comment nous fonctionnons",
  });
};

exports.contactUs = (req, res) => {
  res.status(200).render("contactUs", {
    title: "Kauto.ma | Nous contacter",
  });
};

exports.envEmail = async (req, res) => {
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: process.env.EMAIL_PORT,
      secure: true,
      auth: {
        user: process.env.EMAIL_USERNAME,
        pass: process.env.EMAIL_PASSWORD,
      },
    });

    await transporter.sendMail({
      from: req.body.email,
      to: process.env.EMAIL_USERNAME,
      subject: req.body.subject,
      text: req.body.txtbody,
    });

    res.status(200).render("status", {
      title: "✅ Succès!!",
      message: "Email envoyé",
      statusMesssage: "succes",
    });
  } catch (err) {
    return next(new appError("une erreur s'est produite lors de l'envoi de l'e-mail, veuillez réessayer", 500));
  }
};

exports.aboutUs = (req, res) => {
  res.status(200).render("aboutUs", {
    title: "Kauto.ma | à propos de nous",
  });
};
