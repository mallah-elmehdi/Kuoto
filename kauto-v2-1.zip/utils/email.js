const nodemailer = require("nodemailer");
const EmailTemplate = require("email-templates");

const sendEmail = async options => {
  const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    secure: true,
    auth: {
      user: process.env.EMAIL_USERNAME,
      pass: process.env.EMAIL_PASSWORD
    }
  });

  const email = new EmailTemplate({
    message: {
      from: process.env.EMAIL_USERNAME
    },
    send:true,
    preview:false,
    transport: transporter
  });

  await email.send({
    template: options.what,
    message: {
      to: options.email
    },
    locals: {
      urlToken: options.urlToken
    }
  });
};

module.exports = sendEmail;
