$(function () {
    $('[data-toggle="popover"]').popover()
  })

// //=====================================

// $(window).on("load", function() {
//   $(".charge").hide();
// });

// $("#contact-us").keyup(function() {
//   var lgt = $("#contact-us").val().length;
//   $(".txtlengh")[0].innerHTML = `${lgt}/500`;
//   if (lgt === 500) $(".txtlengh").addClass("text-danger");
//   if (lgt < 500) $(".txtlengh").removeClass("text-danger");
// });

// $("#contact-us1").keyup(function() {
//   var lgt = $("#contact-us1").val().length;
//   $(".txtlengh1")[0].innerHTML = `${lgt}/50`;
//   if (lgt === 50) $(".txtlengh1").addClass("text-danger");
//   if (lgt < 50) $(".txtlengh1").removeClass("text-danger");
// });

// $(".sock").submit(function(e) {
//   var user = $(this).attr("userId");
//   var id = $(this).attr("id");
//   $(`#like-${id}`).toggleClass("text-danger text-secondary");

//   if ($(`#like-${id}`).hasClass("text-danger")) {
//     $(`#input-${id}`).attr("value", id);
//   } else if ($(`#like-${id}`).hasClass("text-secondary")) {
//     $(`#input-${id}`).attr("value", `no-${id}`);
//   }

//   e.preventDefault();
//   $.ajax({
//     global: false,
//     type: "POST",
//     url: `/utilisateur/${user}`,
//     dataType: "html",
//     data: {
//       like: $(`#input-${id}`).val()
//     }
//   });
// });

// $(".hoyi").hide();
// $(".yohi").click(function() {
//   $(".hoyi").show();
//   $(".yohi").addClass("disabled");
//   $(".yohi").addClass("text-dark");
//   $(".yohi")[0].innerHTML = "";

//   $(".yohi").removeClass("text-danger");

//   $(".yami").click(function() {
//     $(".hoyi").hide();
//     $(".yohi").removeClass("disabled");
//     $(".yohi").removeClass("text-dark");
//     $(".yohi")[0].innerHTML = "Supprimer le compte";

//     $(".yohi").addClass("text-danger");
//   });
// });

// if ($(window).width() >= 1173) {
//   $("span.camcam").show();
// } else {
//   $("span.camcam").hide();
//   $(".lamlam").addClass("text-center");
// }

// $(".motdepass").keyup(function() {
//   var letterNumber = /(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{8,20})$/;
//   if (
//     $(".motdepass")
//       .val()
//       .match(letterNumber)
//   ) {
//     $(".motdepass").addClass("is-valid");
//     $(".motdepass").removeClass("is-invalid");
//     this.setCustomValidity("");
//   } else {
//     $(".motdepass").addClass("is-invalid");
//     $(".motdepass").removeClass("is-valid");
//     if (
//       $(".motdepass").val().length > 8 &&
//       $(".motdepass").hasClass("is-invalid")
//     )
//       this.setCustomValidity("minimum of 1 letter and 1 number");
//   }
// });

// $(".remotdepass").keyup(function() {
//   if ($(".motdepass").hasClass("is-invalid")) {
//     $(".remotdepass").addClass("is-invalid");
//     $(".remotdepass").removeClass("is-valid");
//     this.setCustomValidity("The password confirmation does not match");
//   } else {
//     if ($(".remotdepass").val() === $(".motdepass").val()) {
//       $(".remotdepass").addClass("is-valid");
//       $(".remotdepass").removeClass("is-invalid");
//       this.setCustomValidity("");
//     } else {
//       $(".remotdepass").addClass("is-invalid");
//       $(".remotdepass").removeClass("is-valid");
//       this.setCustomValidity("The password confirmation does not match");
//     }
//   }
// });

// if ($(window).width() >= 991) {
//   $(".dropdowna-content").addClass("zidliman");
// } else {
//   $(".dropdowna-content").removeClass("zidliman");
// }
$(document).ready(function () {
  if ($("#footer")) {
    var r = 0;
    $.getJSON("/../json/cities.json", function (result) {
      $.each(result, function (i) {
        if (i % 56 === 0) {
          r++;
          $("#list-cities").append(`<div class="col-lg-3 col-md-4 col-sm-6 mb-3"><div id='item-${r}' class="row"></div></div>`);
        }
        $(`#item-${r}`).append(`<div class="col-12"><form action="/" method="post"><input class="d-none" type="text" name="secteur" value="all"><input class="d-none" type="text" name="marque" value="all"><input class="d-none" type="text" name="modele" value="all"><button type="submit" name="ville" value='${JSON.stringify(result[i])}' class="btn btn-sm btn-link text-dark">${result[i].fr}</button></form></div>`);
      });
    });

    var q = 0;
    $.getJSON("/../json/cars.json", function (result) {
      $.each(result, function (i) {
        if (i % 16 === 0) {
          q++;
          $("#list-brands").append(`<div class="col-lg-3 col-md-4 col-sm-6 mb-3"><div id='atem-${q}' class="row"></div></div>`);
        }
        $(`#atem-${q}`).append(`<div class="col-12"><form action="/" method="post"><input class="d-none" type="text" name="secteur" value="all"><input class="d-none" type="text" name="ville" value="all"><input class="d-none" type="text" name="modele" value="all"><button type="submit" name="marque" value='${JSON.stringify(result[i])}' class="btn btn-sm btn-link text-dark">${result[i].fr}</button></form></div>`);
      });
    });
  }
  
  if ($(".car-card")) {
  const carCard = $(".car-card");
  carCard.mouseover(function () {
        $(this).addClass("shadow");
        carCard.mouseout(function () {
          $(this).removeClass("shadow");
        });
      });
  }
  
  if ("#copy") {
    var scrollbar = document.getElementsByTagName("body")[0].scrollHeight;

    if (scrollbar < window.innerHeight) $("#copy").addClass("fixed-bottom");
    if (scrollbar >= window.innerHeight) $("#copy").removeClass("fixed-bottom");
  }
});
