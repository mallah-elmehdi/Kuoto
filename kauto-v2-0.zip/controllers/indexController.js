const fs = require("fs");
const review = require("../models/reviewModel");
const car = require("../models/carModel");
const user = require("../models/userModel");
const store = require("../models/storeModel");
const appError = require("../utils/appErrors");
const catchAsync = require("../utils/catchAsync");
const nodemailer = require("nodemailer");

// ===== DATA

const cities = JSON.parse(fs.readFileSync(`${__dirname}/../json/cities.json`));
const brands = JSON.parse(fs.readFileSync(`${__dirname}/../json/cars.json`));
const types = JSON.parse(fs.readFileSync(`${__dirname}/../json/types.json`));
const propeties = JSON.parse(fs.readFileSync(`${__dirname}/../json/propeties.json`));

// ===== GET THE MAIN PAGE

exports.getIndex = catchAsync(async (req, res, next) => {
  var list = [];
  var cars = [];
  var j = 0;

  var stores = await store.find({ emailValide: "YES", store: { city: { fr: req.ipInfo.city } } });
  if (!stores.length) stores = await store.find({ emailValide: "YES" });

  for (var i = 0; i < stores.length; i++) {
    var carCheap = await car.find({ store: stores[i].id }).sort({ price: 1 }).limit(1).populate("store");

    if (carCheap[0]) {
      list[j] = {
        coordinates: stores[i].store.location.coordinates,
        price: carCheap[0].price,
        id: stores[i].id,
      };
      cars[j] = carCheap[0];
      j++;
    }
  }

  res.status(200).render("index", {
    title: "Kauto.ma | site gratuit de location des voitures",
    cities,
    brands,
    stores,
    cars,
    propeties,
    list,
  });
});

// ===== CAR DETAILS

exports.carDetails = catchAsync(async (req, res, next) => {
  const carDetail = await car.findById(req.params.id).populate("store");

  if (!carDetail) {
    return next(new appError("Aucune voiture a cette identité"), 404);
  }
  //   const reviews = await review.find({ which: req.params.id }).populate("from");

  res.status(200).render("carDetail", {
    title: `${carDetail.marque.fr} - ${carDetail.model.fr}`,
    propeties,
    carDetail,
  });
});

// ===== SEARCH

exports.searchPage = catchAsync(async (req, res, next) => {
  // if (!req.query.ville) {
  //   res.redirect("/");
  //   return 0;
  // }
  var query = "";
  var carsSearch;
  var ville = req.query.ville;
  var marque = req.query.marque;
  var type = req.query.type;
  var page = (req.query.page * 1 - 1) * 60;
  var resultat = 0;

  if (req.query.filter) {
    type = req.query.filter;
  }
  if (ville === "Tout le Maroc") {
    ville = /^/;
  }
  if (marque === "Toutes les marques") {
    marque = /^/;
  }
  if (type === "Tous les types") {
    type = /^/;
  }

  if (!req.query.trier && !req.query.propriete) {
    carsSearch = await car
      .find({
        checked: /^Oui/,
        marque: marque,
        type: type,
      })
      .populate("store", "store _id");

    if (req.query.filter) query = `?ville=${req.query.ville}&marque=${req.query.marque}&type=${req.query.type}&filter=${req.query.filter}&page=${req.query.page}`;
    query = `?ville=${req.query.ville}&marque=${req.query.marque}&type=${req.query.type}&page=${req.query.page}`;
  }
  if (req.query.propriete) {
    var prop = req.query.propriete.split(",");
    var count = prop.length;
    var carburant = [];
    var price = "";
    var boite = "";
    var r = 0;
    if (prop[count - 1] === "") prop.pop();
    if (prop[0] === "1" || prop[0] === "2" || prop[0] === "3" || prop[0] === "4" || prop[0] === "5") {
      price = prop[0];
      r = 1;
    }

    if (prop[count - 2] === "M") {
      for (var i = r; i < count - 2; i++) {
        carburant[i] = prop[i];
      }
    } else if (prop[count - 1] === "M" || (prop[count - 1] === "A" && prop[count - 2] != "M")) {
      boite = prop[count - 1];
      for (var i = r; i < count - 1; i++) {
        carburant[i] = prop[i];
      }
    } else if (prop[count - 1] != "A" && prop[count - 1] != "M") {
      for (var i = r; i < count - 1; i++) {
        carburant[i] = prop[i];
      }
    }

    if (carburant.length === 0) carburant = /^/;
    if (boite === "") boite = /^/;

    if (price === "1")
      carsSearch = await car
        .find({
          checked: /^Oui/,
          marque: marque,
          type: type,
          carburant: { $in: carburant },
          boite: boite,
          price: { $gt: 1000 },
        })
        .populate("store", "store _id");
    if (price === "2")
      carsSearch = await car
        .find({
          checked: /^Oui/,
          marque: marque,
          type: type,
          carburant: { $in: carburant },
          boite: boite,
          price: { $lte: 1000, $gt: 800 },
        })
        .populate("store", "store _id");
    if (price === "3")
      carsSearch = await car
        .find({
          checked: /^Oui/,
          marque: marque,
          type: type,
          carburant: { $in: carburant },
          boite: boite,
          price: { $lte: 800, $gt: 400 },
        })
        .populate("store", "store _id");
    if (price === "4")
      carsSearch = await car
        .find({
          checked: /^Oui/,
          marque: marque,
          type: type,
          carburant: { $in: carburant },
          boite: boite,
          price: { $lte: 400, $gt: 200 },
        })
        .populate("store", "store _id");
    if (price === "5")
      carsSearch = await car
        .find({
          checked: /^Oui/,
          marque: marque,
          type: type,
          carburant: { $in: carburant },
          boite: boite,
          price: { $lte: 200 },
        })
        .populate("store", "store _id");
    if (price === "") {
      carsSearch = await car
        .find({
          checked: /^Oui/,
          marque: marque,
          type: type,
          carburant: { $in: carburant },
          boite: boite,
        })
        .populate("store", "store _id");
    }
    query = `?ville=${req.query.ville}&marque=${req.query.marque}&type=${req.query.type}&propriete=${req.query.propriete}&page=${req.query.page}`;
  }

  if (req.query.trier === "Prix2") carsSearch = await car.find({ checked: /^Oui/, marque: marque, type: type }).sort({ price: -1 }).populate("store", "store _id");

  if (req.query.trier === "Prix1") carsSearch = await car.find({ checked: /^Oui/, marque: marque, type: type }).sort({ price: 1 }).populate("store", "store _id");

  if (req.query.trier === "Porte2") carsSearch = await car.find({ checked: /^Oui/, marque: marque, type: type }).sort({ porte: 1 }).populate("store", "store _id");

  if (req.query.trier === "Porte1") carsSearch = await car.find({ checked: /^Oui/, marque: marque, type: type }).sort({ porte: -1 }).populate("store", "store _id");

  if (req.query.trier === "Place2") carsSearch = await car.find({ checked: /^Oui/, marque: marque, type: type }).sort({ place: 1 }).populate("store", "store _id");

  if (req.query.trier === "Place1") carsSearch = await car.find({ checked: /^Oui/, marque: marque, type: type }).sort({ place: -1 }).populate("store", "store _id");

  if (query === "") query = `?ville=${req.query.ville}&marque=${req.query.marque}&type=${req.query.type}&trier=${req.query.trier}&page=${req.query.page}`;
  resultat = carsSearch.length;
  for (let i = 0; i < page; i++) {
    carsSearch.shift();
  }
  while (carsSearch.length > 60) {
    carsSearch.pop();
  }
  if (resultat > 60 && req.query.page * 1 > resultat / 60 + (resultat % 60) - 1) return next(new appError("Page non trouvée", 404));
  res.locals.cars = carsSearch;
  res.status(200).render("search", {
    title: "Kauto.ma | site gratuit de location des voitures",
    query,
    propeties,
    resultat,
    page: req.query.page,
  });
});

exports.searchCars = catchAsync(async (req, res, next) => {
  var page = 1;
  if (req.body.page) {
    if (req.body.page === "+1") page = req.query.page * 1 + 1;
    else if (req.body.page === "-1") page = req.query.page * 1 - 1;
    else page = req.body.page;
  }
  if (req.body.price || req.body.carburant || req.body.boite || req.query.propriete) {
    var filter = "";
    if (req.query.propriete) filter = req.query.propriete;
    if (req.body.reset) filter = "";
    if (req.body.price) filter = filter + req.body.price + ",";
    if (req.body.carburant) filter = filter + req.body.carburant + ",";
    if (req.body.boite) filter = filter + req.body.boite;
    res.redirect(`/resultat?ville=${req.query.ville}&marque=${req.query.marque}&type=${req.query.type}&propriete=${filter}&page=${page}`);
    return 0;
  } else if (req.body.ele || req.query.trier) {
    var trier = "";
    if (req.query.trier) trier = req.query.trier;
    if (req.body.ele) trier = req.body.ele;
    res.redirect(`/resultat?ville=${req.query.ville}&marque=${req.query.marque}&type=${req.query.type}&trier=${trier}&page=${page}`);
    return 0;
  } else if (req.body.element || req.query.filter) {
    var filter = "";
    if (req.query.filter) filter = req.query.filter;
    if (req.body.element) filter = req.body.element;
    res.redirect(`/resultat?ville=${req.query.ville}&marque=${req.query.marque}&type=${req.query.type}&filter=${filter}&page=${page}`);
    return 0;
  } else if (req.query.ville) {
    res.redirect(`/resultat?ville=${req.query.ville}&marque=${req.query.marque}&type=${req.query.type}&page=${page}`);
    return 0;
  }
  res.redirect(`/resultat?ville=${req.body.ville}&marque=${req.body.marque}&type=${req.body.type}&page=1`);
});

// LAW

exports.PrivacyPolicy = (req, res) => {
  res.status(200).render("PrivacyPolicy", {
    title: "Kauto.ma | Privacy Policy ",
  });
};

exports.termsandconditions = (req, res) => {
  res.status(200).render("termsandconditions", {
    title: "Kauto.ma | Terms And Conditions",
  });
};

exports.Desclaimer = (req, res) => {
  res.status(200).render("Desclaimer", {
    title: "Kauto.ma | Desclaimer",
  });
};

exports.howitworks = (req, res) => {
  res.status(200).render("howitworks", {
    title: "Kauto.ma | Comment nous fonctionnons",
  });
};

exports.contactUs = (req, res) => {
  res.status(200).render("contactUs", {
    title: "Kauto.ma | Nous contacter",
  });
};

exports.envEmail = async (req, res) => {
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: process.env.EMAIL_PORT,
      secure: true,
      auth: {
        user: process.env.EMAIL_USERNAME,
        pass: process.env.EMAIL_PASSWORD,
      },
    });

    await transporter.sendMail({
      from: req.body.email,
      to: process.env.EMAIL_USERNAME,
      subject: req.body.subject,
      text: req.body.txtbody,
    });

    res.status(200).render("status", {
      title: "✅ Succès!!",
      message: "Email envoyé",
      statusMesssage: "succes",
    });
  } catch (err) {
    return next(new appError("une erreur s'est produite lors de l'envoi de l'e-mail, veuillez réessayer", 500));
  }
};

exports.aboutUs = (req, res) => {
  res.status(200).render("aboutUs", {
    title: "Kauto.ma | à propos de nous",
  });
};
