const user = require("../models/userModel");
const car = require("../models/carModel");
const review = require("../models/reviewModel");
const catchAsync = require("../utils/catchAsync");
const appError = require("../utils/appErrors");
const fs = require("fs");

//===== DATA

const propeties = JSON.parse(
  fs.readFileSync(`${__dirname}/../json/propeties.json`)
);

exports.getUserProfile = catchAsync(async (req, res, next) => {
  if (res.locals.user.role != "user")
    return next(new appError("Vous n'êtes pas autorisé", 401));
  var message = "";
  if (
    req.query.message
  )
    message = req.query.message;
  var cars = [];
  for (var i = 0; i < res.locals.user.favorite.length; i++) {
    var fav = await car
      .findById(res.locals.user.favorite[i])
      .populate("store", "store _id");
    cars[i] = fav;
  }
  if (cars.length === 0) {
    cars = await car
      .find({ checked: /^Oui/ })
      .sort({ price: 1 })
      .limit(8)
      .populate("store", "store _id");
  }

  res.status(200).render("userProfile", {
    title: "Kauto.ma | Profile",
    cars,
    part: "1",
    propeties,
  });
});

exports.getUserProfileComm = catchAsync(async (req, res, next) => {
  if (res.locals.user.role != "user")
    return next(new appError("Vous n'êtes pas autorisé", 401));
  var message = "";
  if (
    req.query.message
  )
    message = req.query.message;
  const reviews = await review
    .find({ from: res.locals.user.id })
    .populate("which");
  var cars = [];
  cars = await car
    .find({ checked: /^Oui/ })
    .sort({ price: 1 })
    .limit(8)
    .populate("store", "store _id");

  res.status(200).render("userProfile", {
    title: "Kauto.ma | Profile",
    part: "2",
    cars,
    propeties,
    reviews,
  });
});

exports.addFarorite = catchAsync(async (req, res, next) => {
  if (res.locals.user.role != "user")
    return next(new appError("Vous n'êtes pas autorisé", 401));
  if (req.cookies.cookie) {
    if (req.body.like.startsWith("no"))
      res.locals.user.favorite = res.locals.user.favorite.filter(
        (word) => word != req.body.like.split("no-")[1]
      );
    else if (!res.locals.user.favorite.includes(req.body.like))
      res.locals.user.favorite.push(req.body.like);

    await res.locals.user.save();
  }
});

exports.clearFav = catchAsync(async (req, res, next) => {
  if (res.locals.user.role != "user")
    return next(new appError("Vous n'êtes pas autorisé", 401));
  if (req.cookies.cookie) {
    if (req.body.all) {
      res.locals.user.favorite = [];
      await res.locals.user.save();
      res.redirect(`/utilisateur/${req.params.id}`);
    }
  }
});

exports.supprimerUser = catchAsync(async (req, res, next) => {
  if (res.locals.user.role != "user")
    return next(new appError("Vous n'êtes pas autorisé", 401));
  var message = "";
  if (
    req.query.message
  )
    message = req.query.message;
  const deleteUser = await user.findByIdAndDelete(req.params.id);
  if (!deleteUser)
    return next(new appError("Aucun compte trouvée avec cette identité!", 404));
  const reviews = await review.find({ from: req.params.id });
  if (reviews) {
    for (let i = 0; i < reviews.length; i++) {
      await review.findByIdAndDelete(reviews[i].id);
    }
  }
  res.clearCookie("cookie");
  res.redirect("/");
});

exports.addComment = catchAsync(async (req, res, next) => {
  if (res.locals.user.role != "user")
    return next(new appError("Vous n'êtes pas autorisé", 401));
  const isreview = await review.findOne({
    from: req.params.id,
    to: req.params.toid,
    which: req.params.wid,
  });
  if (isreview) {
    var message = encodeURIComponent("Vous avez déjà ajouté un commentaire");
    res.redirect(`/details/${req.params.wid}/?message=${message}`);
    return 0;
  }
  const newComment = await review.create({
    to: req.params.toid,
    from: req.params.id,
    which: req.params.wid,
    star: req.body.star,
    comment: req.body.comment,
    at: Date.now(),
  });
  if (!newComment) {
    var message = encodeURIComponent(
      "Commentaire n'a pas été créé, veuillez réessayer"
    );
    res.redirect(`/details/${req.params.wid}/?message=${message}`);
    return 1;
  }
  res.redirect(`/details/${req.params.wid}`);
});
