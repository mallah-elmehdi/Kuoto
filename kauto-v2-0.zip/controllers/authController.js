const catchAsync = require("../utils/catchAsync");
const appError = require("../utils/appErrors");
const { promisify } = require("util");
const user = require("../models/userModel");
const store = require("../models/storeModel");
const jwt = require("jsonwebtoken");
const car = require("../models/carModel");

// ============ AUTHORIZED

exports.restrictTo = async (req, res, next) => {
  var currentCar;
  if (req.params.cid) {
    currentCar = await car.findById(req.params.cid);
  }
  if (!res.locals.user || req.params.id != res.locals.user.id || (currentCar && currentCar.store != req.params.id)) {
    return next(new appError("Vous n'êtes pas autorisé", 401));
  }
  next();
};

exports.forbidden = (req, res, next) => {
  if (req.cookies.cookie) {
    return next(new appError("vous devez d'abord déconnecter", 403));
  }
  next();
};

// ============ LOGGED IN

exports.userLoggedIn = async (req, res, next) => {
  if (req.cookies.cookie) {
    try {
      const decoded = await promisify(jwt.verify)(req.cookies.cookie, process.env.JWT_SECRET);
      var userConnect = await user.findById(decoded.id);
      
      if (!userConnect) userConnect = await store.findById(decoded.id);
      if (!userConnect || userConnect.changedPasswordAfter(decoded.iat)) return next();

      res.locals.user = userConnect;
      return next();
      
    } catch (err) {
      return next(err);
    }
  }
  next();
};

exports.protection = catchAsync(async (req, res, next) => {
  const decoded = await promisify(jwt.verify)(req.query.cle, process.env.JWT_SECRET);
  if (req.params.id === decoded.id) {
    next();
  } else return next(new appError("Vous n'êtes pas autorisé", 400));
});

exports.protect = catchAsync(async (req, res, next) => {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    token = req.headers.authorization.split(" ")[1];
  } else if (!token) {
    throw new Error("accessError");
  } else {
    const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);
    const currentUser = await user.findById(decoded.id);
    if (!currentUser) {
      throw new Error("noUserError");
    } else if (currentUser.changedPasswordAfter(decoded.iat)) {
      throw new Error("passwordChangedError");
    } else {
      req.user = currentUser;
      next();
    }
  }
});

exports.authError = (err, req, res, next) => {
  let error = {
    ...err,
  };
  if (err.message === "accessError" || err.name === "JsonWebTokenError" || err.name === "TokenExpiredError" || err.message === "noUserError") {
    error = new appError("Vous n'êtes pas connecté! Veuillez vous connecter pour avoir accès", 401);
  } else if (err.message === "passwordChangedError") {
    error = new appError("Mot de passe changé! Veuillez vous reconnecter.", 401);
  } else if (err.message === "promissionError") {
    error = new appError("Vous n'êtes pas autorisé à effectuer cette action", 403);
  }
};
