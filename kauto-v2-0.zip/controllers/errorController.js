const fs = require("fs");
const cities = JSON.parse(fs.readFileSync(`${__dirname}/../json/cities.json`));
const appError = require("../utils/appErrors");

// const sendErrorDev = (err, res) => {
//   res.status(err.statusCode).json( {
//     status: err.status,
//     error: err,
//     message: err.message,
//     stack: err.stack
//   });
// };

const sendErrorProd = (err, res) => {
  if (err.isOperational) {
    res.status(err.statusCode).render("status", {
      title: `ERROR! - ${err.statusCode} 💥`,
      message: err.message,
      statusMesssage: "error",
    });
  } else {
    res.status(500).render("status", {
      title: "ERROR! - 500 💥",
      message: "Une erreur s'est produite. Veuillez réessayer",
      statusMesssage: "error",
    });
  }
};

// ================================== INDEX REDIRECT

exports.redirectIndex = (err, req, res, next) => {
  if (err.statusCode) return next(err);

  try {
    req.flash("message", err);
    return res.redirect("/");
  } 
  
  catch (err) {
    next(err);
  }
};

// ============ TOKEN ERROR

exports.tokenErrorHandler = (err, req, res, next) => {
  if (err.statusCode === 500) next(err);
  try {
    res.status(err.statusCode).render("status", {
      title: "ERROR! 💥",
      message: err.message,
      statusMesssage: "fail",
    });
  } catch {
    return next(new appError("une erreur s'est produite, veuillez réessayer", 500));
  }
};

// ============ VALIDATION ERROR

exports.validationErrorHandler = (err, req, res, next) => {
  if (req.file) {
    fs.unlink(`${__dirname}/../graphics/stores/${req.file.filename}`, (err) => {
      if (err) return next(err);
    });
  }
  if (err && err.statusCode === 500) return next(err);

  if (err && err.name === "ValidationError") {
    if (err.errors.name) return next(new appError(err.errors.name.message, 400));
    var message = err.message.split(": ")[2];
    return next(new appError(message, 400));
  }

  if (err && err.code === 11000) {
    return next(new appError("Email est déjà enregistré, Veuillez utiliser un autre e-mail!", 400));
  }
  next(err);
};

// ============ STORE ERROR

// exports.storeAddErrorHandler = (err, req, res, next) => {
//   if (err.statusCode === 500 || err.message === "Vous n'êtes pas connecté") return next(err);

//   var message = encodeURIComponent(err.message);
//   res.redirect(`/mon-agence/${req.params.name}/${req.params.id}/ajouter/?message=` + message);
// };

// ============ STORE CREATION ERROR

// exports.creatStoreErrorHandler = (err, req, res, next) => {
//   if (err && err.statusCode === 500) return next(err);

//   res.status(err.statusCode).render("creerBoutique", {
//     title: "Kauto.ma | Créer votre agence",
//     message: err.message,
//     data: {
//       cities,
//     },
//     body: req.body,
//   });
// };

// ============ CONNECTION ERROR

// exports.seConnecter = (err, req, res, next) => {
//   // if (err.statusCode === 500) return next(err);

//   res.redirect(`/se-connecter?message=${err.message}&status=${err.statusCode}&data=${req.body.email}`)

//   // res.status(err.statusCode).render("seConnecter", {
//   //   title: "Kauto.ma | Se conneter",
//   //   message: err.message,
//   //   data: req.body.email,
//   // });
// };

// ============ RESET-PASSWORD ERROR

// exports.resetPassword = (err, req, res, next) => {
//   if (err.statusCode === 500) return next(err);

//   res.status(err.statusCode).render("resetPassword", {
//     title: "Kauto.ma | Réinitialiser le mot de passe",
//     message: err.message,
//     data: req.body.email,
//   });
// };

// ============ STORE CREATION ERROR

// exports.inscriptionErrorHandler = (err, req, res, next) => {
//   if (err.statusCode === 500) return next(err);

//   res.status(err.statusCode).render("inscrire", {
//     title: "Kauto.ma | S'inscrire",
//     message: err.message,
//     data: req.body,
//   });
// };

// ============ PASS CHANGE ERROR

exports.changePassErrorHandler = (err, req, res, next) => {
  if (err.statusCode === 500) return next(err);

  var message = encodeURIComponent(err.message);
  res.redirect(`/mon-agence/${req.params.name}/${req.params.id}/changer-le-mot-de-passe/verifie/?cle=${req.query.cle}&message=${message}`);
};

// ============  AUTHENTICATION TO HOME ERROR

exports.authenticationErrorHandler = (err, req, res, next) => {
  if (err.statusCode === 500) return next(err);
  if (err.name === "JsonWebTokenError") err.message = "Vous n'êtes pas autorisé";
  var message = encodeURIComponent(err.message);
  res.redirect("/?message=" + message);
};

// ============  PASSWORD CHANGE ERROR

exports.passCheckError = (err, req, res, next) => {
  if (err.statusCode != 400) return next(err);
  var message = encodeURIComponent(err.message);
  var restant = encodeURIComponent(res.locals.remaining);

  res.redirect(`/mon-agence/${req.params.name}/${req.params.id}/changer-le-mot-de-passe/?message=${message}&restant=${restant}`);
};

// ============ GLOBAL ERROR

exports.globalErrorHandler = (err, req, res, next) => {
  err.statusCode = err.statusCode || 500;
  err.status = err.status || "error";
  sendErrorProd(err, res);
  // if (process.env.NODE_ENV === "development") {
  //   sendErrorDev(err, res);
  // } else if (process.env.NODE_ENV === "production") {
  //   sendErrorProd(err, res);
  // }
};
