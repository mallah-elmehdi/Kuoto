const user = require("../models/userModel");
const car = require("../models/carModel");
const appError = require("../utils/appErrors");
const catchAsync = require("../utils/catchAsync");
const fs = require("fs");

const propeties = JSON.parse(
  fs.readFileSync(`${__dirname}/../json/propeties.json`)
);
const carburant = JSON.parse(
  fs.readFileSync(`${__dirname}/../json/carburant.json`)
);
const brands = JSON.parse(fs.readFileSync(`${__dirname}/../json/cars.json`));
const boites = JSON.parse(fs.readFileSync(`${__dirname}/../json/boite.json`));
const types = JSON.parse(fs.readFileSync(`${__dirname}/../json/types.json`));

exports.viewBoutique = catchAsync(async (req, res, next) => {
  const boutique = await user.findById(req.params.id);
  const cars = await car.find({ store: req.params.id });

  boutique.store.name = boutique.store.name
    .split("o")
    .join(" ")
    .toLowerCase();
  boutique.store.adresse = boutique.store.adresse
    .split("o")
    .join(" ")
    .toLowerCase();

  res.status(200).render("viewBoutique", {
    title: `Agence | ${boutique.store.name}`,
    boutique,
    propeties,
    part: 1,
    cars,
    data: {
      brands,
      boites,
      types,
      carburant
    }
  });
});

exports.viewBoutiqueOffre = catchAsync(async (req, res, next) => {
  const boutique = await user.findById(req.params.id);
  const cars = await car.find({ store: req.params.id });

  boutique.store.name = boutique.store.name
    .split("o")
    .join(" ")
    .toLowerCase();
  boutique.store.adresse = boutique.store.adresse
    .split("o")
    .join(" ")
    .toLowerCase();

  res.status(200).render("viewBoutique", {
    title: `Agence | ${boutique.store.name}`,
    boutique,
    propeties,
    cars,
    part: 2,
    data: {
      brands,
      boites,
      types,
      carburant
    }
  });
});

exports.sorting = catchAsync(async (req, res, next) => {
  const boutique = await user.findById(req.params.id);

  if (req.body.ele === "Prix1")
    var cars = await car.find({ store: req.params.id }).sort({ price: 1 });

  if (req.body.ele === "Prix2")
    var cars = await car.find({ store: req.params.id }).sort({ price: -1 });

  if (req.body.ele === "Porte2")
    var cars = await car.find({ store: req.params.id }).sort({ porte: 1 });

  if (req.body.ele === "Porte1")
    var cars = await car.find({ store: req.params.id }).sort({ porte: -1 });

  if (req.body.ele === "Place2")
    var cars = await car.find({ store: req.params.id }).sort({ place: 1 });

  if (req.body.ele === "Place1")
    var cars = await car.find({ store: req.params.id }).sort({ place: -1 });

  if (req.body.search) {
    req.body.search = req.body.search.toUpperCase();
    var i = 0;
    var o = 0;
    while (i < brands.length) {
      if (brands[i].type.includes(req.body.search)) {
        var cars = await car.find({
          store: req.params.id,
          marque: { $gte: req.body.search }
        });
        o = 1;
        i = brands.length;
      }
      i++;
    }
    if (o === 0)
      var cars = await car.find({
        store: req.params.id,
        model: req.body.search
      });
  }

  boutique.store.name = boutique.store.name
    .split("o")
    .join(" ")
    .toLowerCase();
  boutique.store.adresse = boutique.store.adresse
    .split("o")
    .join(" ")
    .toLowerCase();

  res.status(200).render("viewBoutique", {
    title: `Agence | ${boutique.store.name}`,
    boutique,
    propeties,
    cars,
    part: 2,
    data: {
      brands,
      boites,
      types,
      carburant
    }
  });
});
