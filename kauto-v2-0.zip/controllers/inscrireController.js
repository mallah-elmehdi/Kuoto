const appError = require("../utils/appErrors");
const user = require("../models/userModel");
const catchAsync = require("../utils/catchAsync");
const authToken = require("../utils/authToken");
const sendEmail = require("../utils/email");
const crypto = require("crypto");

// ======================================================== GET

exports.get = (req, res, next) => {
  if (req.cookies.cookie) return next("Vous êtes déjà connecté");

  try {
    res.status(200).render("inscrire", {
      title: "Kauto.ma | S'inscrire",
    });
  } catch (err) {
    next(new appError("Une erreur s'est produite. Réessayez plus tard!", 500));
  }
};

// ======================================================== NEW USER + Send Email

exports.creatUser = catchAsync(async (req, res, next) => {
  const newUser = await user.create({
    name: req.body.name.toLowerCase(),
    email: req.body.email,
    password: req.body.password,
  });

  const emailValidtore = newUser.createPasswordResetToken(60);
  const resetURL = `https://kauto.ma/inscrire/${emailValidtore}`;

  await newUser.save({ validateBeforeSave: false });

  try {
    await sendEmail({
      email: req.body.email,
      what: "verification",
      urlToken: resetURL,
    });

    req.flash("notification", "vérifiez votre email");
    return res.redirect("/");
  } 
  
  catch (err) {
    newUser.passwordResetToken = undefined;
    newUser.passwordResetExpires = undefined;

    await newUser.save({ validateBeforeSave: false });

    return next(new appError("une erreur s'est produite lors de l'envoi de l'e-mail, veuillez réessayer", 500));
  }
});

// ======================================================== Email Vaidatore

exports.userEmailVaidatore = catchAsync(async (req, res, next) => {

  const hashedToken = crypto.createHash("sha256").update(req.params.token).digest("hex");
  const userValide = await user.findOne({ passwordResetToken: hashedToken, passwordResetExpires: { $gt: Date.now() } });
  
  if (!userValide) return next(new appError("Lien n'est pas valide ou expiré", 400));
  
  userValide.emailValide = "YES";
  userValide.passwordResetToken = undefined;
  userValide.passwordResetExpires = undefined;
  await userValide.save();

  const token = authToken.createSendToken(userValide);
  const thecookieOptions = authToken.cookieOptions;
  res.cookie("cookie", token, thecookieOptions);

  req.flash("notification", "Email vérifié");
  return res.redirect("/");
});

// ======================================================== HANDLERS

exports.validation = (err, req, res, next) => {
  if (err.statusCode) return next(err);

  if (err.name === "ValidationError") {
    var message = err.message.split(": ")[2];

    req.flash("message", message);
    req.flash("email", req.body.email);
    req.flash("name", req.body.name);
    return res.redirect("/inscrire");
  }

  if (err.code === 11000) {
    req.flash("message", "Email déjà enregistré");
    req.flash("email", req.body.email);
    req.flash("name", req.body.name);
    return res.redirect("/inscrire");
  }
  next(err);
};
