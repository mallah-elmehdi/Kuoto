const express = require("express");
const userController = require("../controllers/userController");
const maBoutiqueController = require("../controllers/maBoutiqueController");
const errorController = require("../controllers/errorController");
const authController = require("../controllers/authController");

const router = express.Router();

router
  .route("/:id")
  .get(
    authController.userLoggedIn,
    authController.restrictTo,
    userController.getUserProfile,
    errorController.authenticationErrorHandler,
    errorController.globalErrorHandler
  )
  .post(
    authController.userLoggedIn,
    authController.restrictTo,
    userController.addFarorite,
    errorController.authenticationErrorHandler,
    errorController.globalErrorHandler
  );

router
  .route("/:id/commentaires")
  .get(
    authController.userLoggedIn,
    authController.restrictTo,
    userController.getUserProfileComm,
    errorController.authenticationErrorHandler,
    errorController.globalErrorHandler
  );

router
  .route("/:id/clear")
  .post(
    authController.userLoggedIn,
    authController.restrictTo,
    userController.clearFav,
    errorController.authenticationErrorHandler,
    errorController.globalErrorHandler
  );

router
  .route("/:id/se-deconnecter")
  .post(
    authController.userLoggedIn,
    authController.restrictTo,
    // maBoutiqueController.logOut,
    errorController.authenticationErrorHandler,
    errorController.globalErrorHandler
  );

router
  .route("/:id/supprimer")
  .post(
    authController.userLoggedIn,
    authController.restrictTo,
    userController.supprimerUser,
    errorController.authenticationErrorHandler,
    errorController.globalErrorHandler
  );

router
  .route("/:id/commantaire/:toid/voiture/:wid")
  .post(
    authController.userLoggedIn,
    authController.restrictTo,
    userController.addComment,
    errorController.authenticationErrorHandler,
    errorController.globalErrorHandler
  );

module.exports = router;
