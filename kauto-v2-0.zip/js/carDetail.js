$(document).ready(function () {
  const whatsapp = $("#whatsapp");
  $(".whatsapp").click(function () {
    if (whatsapp.hasClass("floating-wpp")) {
      whatsapp.empty();
    }
    whatsapp.floatingWhatsApp({
      phone: `${$(this).data("phone")}`,
      headerTitle: "WhatsApp",
      popupMessage: "Salut comment pouvons-nous vous aider",
      showPopup: true,
      autoOpenTimeout: 10,
      position: "left",
    });
  });
});
