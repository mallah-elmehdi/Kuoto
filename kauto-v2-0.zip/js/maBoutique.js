$(function() {
  $('[data-toggle="tooltip"]').tooltip();
});

// =====

$(".part").click(function() {
  $(".on").addClass("btn-outline-primary");
  $(".on").removeClass("btn-primary");
  $(".on").removeClass("on");
  $(this).addClass("btn-primary");
  $(this).addClass("on");
  $(this).removeClass("btn-outline-primary");
});

// =====

if ($(window).width() >= 1173) {
  $("span.ml-2").show();
} else {
  $("span.ml-2").hide();
  $(".part").addClass("text-center");
}

// =====
$(".remove").hide();
$(document).ready(function() {
  if (window.File && window.FileList && window.FileReader) {
    $("#capics").on("change", function(e) {
      $(".remove").show();

      var files = e.target.files,
        filesLength = files.length;
      for (var i = 0; i < filesLength; i++) {
        var f = files[i];
        var fileReader = new FileReader();
        fileReader.onload = function(e) {
          var text = `<div class="w-100 border rounded p-2 m-1"> <img src="${e.target.result}" width="100%"></div>`;

          // if ($("#capics").val()) {
          //   $("#capics").val(null);
          //   $("#previews").empty();
          // }

          $("#previews").append(text);
          $(".chek").removeClass("btn-warning");
          $(".chek").removeClass("btn-danger");
          $(".chek").addClass("btn-success");

          $(".remove").click(function() {
            $("#previews").empty();
            $(".remove").hide();
            $(".chek").removeClass("btn-danger");
            $(".chek").removeClass("btn-success");
            $(".chek").addClass("btn-warning");
            $("#capics").val(null);
          });
          $(".boom").click(function() {
            $("#previews").empty();
            $(".remove").hide();
            $(".chek").removeClass("btn-success");
            $(".chek").removeClass("btn-danger");
            $(".chek").addClass("btn-warning");
            $("#capics").val(null);
          });
        };

        fileReader.readAsDataURL(f);
      }
      if (filesLength === 0) {
        $("#previews").empty();
        $(".remove").hide();
        $(".chek").removeClass("btn-danger");
        $(".chek").removeClass("btn-success");
        $(".chek").addClass("btn-warning");
      }
    });
  } else {
    alert("Your browser doesn't support to File API");
  }
});

// =====

$(".ajt").click(function() {
  if (!$("#capics").val()) {
    $(".chek").removeClass("btn-warning");
    $(".chek").addClass("btn-danger");
    for (var i = 0; i < 3; i++) {
      $(".chek").fadeOut(200);
      $(".chek").fadeIn(200);
    }
  }
});

var date = Date.now();
$(".charge1").hide();

$(".check").click(function() {
  $(".charge1").fadeIn();
  $(".check").toggleClass("text-success text-secondary");
  if ($(".check").hasClass("text-success")) {
    $(".onOff").attr("value", `Oui at ${date}`);
    $(".disp").attr("title", "cliquez ici pour rendre la voiture indisponible");
  }
  if ($(".check").hasClass("text-secondary")) {
    $(".onOff").attr("value", `Non at ${date}`);
    $(".disp").attr("title", "cliquez ici pour rendre la voiture disponible");
  }
});
