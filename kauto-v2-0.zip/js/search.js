$(function() {
  $('[data-toggle="tooltip"]').tooltip();
});

// =====

$(window).on("load", function() {
  $(".sniper").fadeOut(500);
});

// =====

$(".forum").hide();
$(".trier").click(function() {
  $(".there")[0].innerText = $(this)[0].innerText;
  $(".trier").hide();
  $(".forum").show();
});

$(".up").click(function() {
  $(".elem").attr("value", $(".there")[0].innerText + "1");
  $(".forum").submit();
});

$(".down").click(function() {
  $(".elem").attr("value", $(".there")[0].innerText + "2");
  $(".forum").submit();
});

// =====
$(".toggle").hide();
if ($(window).width() <= 910) {
  $(".toggle").show();
  $(".zero").hide();
  $(".toggle").click(function() {
    $(".zero").animate({
      height: "toggle"
    });
  });
}

// =====

$(".mini").click(function() {
  $(".elm").attr("value", "Pettite");
  $(".ffm").submit();
});

$(".familial").click(function() {
  $(".elm").attr("value", "Familiale");
  $(".ffm").submit();
});

$(".pickup").click(function() {
  $(".elm").attr("value", "Pickup");
  $(".ffm").submit();
});

$(".premium").click(function() {
  $(".elm").attr("value", "Premium");
  $(".ffm").submit();
});

$(".suv").click(function() {
  $(".elm").attr("value", "VUS");
  $(".ffm").submit();
});

// ======

$(".page-link").click(function() {
  if ($(this).attr("aria-label")) {
    if ($(this).attr("aria-label") === "Previous")
      $("#pagination").attr("value", "-1");
    if ($(this).attr("aria-label") === "Next")
      $("#pagination").attr("value", "+1");
    $("#page").submit();
  } else {
    $("#pagination1").attr("value", $(this)[0].innerHTML);
    $("#page1").submit();
  }
});
if ($(".pagini")) {
  var page = $(".pagini").data("page");
  $(`#pg-${page}`).addClass("active");
  if (page === 1) $(".prev").addClass("disabled");
  if ($(".last").hasClass("active")) $(".next").addClass("disabled");
}
