function preview_image(event) {
  var reader = new FileReader();
  reader.onload = function() {
    var text = `<div class="w-100 border rounded p-2 m-1"> <img src="${reader.result}" width="100%"></div>`;
    $("#prview").append(text);
  };
  reader.readAsDataURL(event.target.files[0]);
}

// =====

if ($(window).width() >= 1173) {
  $("span.ml-2").show();
} else {
  $("span.ml-2").hide();
  $(".part").addClass("text-center");
}

// =====

$(".submit").hide();
$("#edit").click(function() {
  $("#filset").removeAttr("disabled");
  $("#edit").hide();
  $(".submit").show();
});

$(function() {
  $('[data-toggle="tooltip"]').tooltip();
});

// =====

$(".part").click(function() {
  $(".on").addClass("btn-outline-primary");
  $(".on").removeClass("btn-primary");
  $(".on").removeClass("on");
  $(this).addClass("btn-primary");
  $(this).addClass("on");
  $(this).removeClass("btn-outline-primary");
});

// =====
if (document.getElementById("mapo")) {
  var loc = JSON.parse(document.getElementById("mapo").dataset.location);
  var marker, uluru;
  uluru = { lat: loc[1], lng: loc[0] };

  $("#map").click(function() {
    if (navigator.geolocation) {
      $(".ggl-map").removeClass("btn-warning");
      $(".ggl-map").addClass("btn-success");
      navigator.geolocation.getCurrentPosition(showPosition);
    }
  });
  function markerLocation() {
    $("#lati").attr("value", marker.getPosition().lat());
    $("#long").attr("value", marker.getPosition().lng());
  }

  function initMap() {
    var map = new google.maps.Map(document.getElementById("mapo"), {
      zoom: 15,
      center: uluru
    });
    marker = new google.maps.Marker({
      position: new google.maps.LatLng(uluru),
      map: map
    });
    google.maps.event.addListener(map, "click", function(event) {
      var clickedLocation = event.latLng;
      marker.setPosition(clickedLocation);
      markerLocation();
    });
  }

  function showPosition(position) {
    uluru = {
      lat: position.coords.latitude,
      lng: position.coords.longitude
    };
    $("#lati").attr("value", position.coords.latitude);
    $("#long").attr("value", position.coords.longitude);
    initMap();
  }
}

// ======

$(".parametoo").hide();
$(".taniya").hide();

$(".parametragoo").click(function() {
  var oh = $(this).attr("kayna");
  $(`.mo${oh}`).fadeToggle();
});

$(".lawla").click(function() {
  var oh = $(this).attr("kayna");
  $(`.n${oh}`).hide();
  $(`.na${oh}`).show();
  $(`.x${oh}`).show();
});

$(".taniya").click(function() {
  var oh = $(this).attr("kayna");
  $(`.n${oh}`).show();
  $(`.na${oh}`).hide();
  $(`.x${oh}`).hide();
});

// =======


