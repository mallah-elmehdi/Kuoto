$(function() {
  $('[data-toggle="tooltip"]').tooltip();
});

// =====
if (document.getElementById("map")) {
  const loc = JSON.parse(document.getElementById("map").dataset.location);
  const lng = loc[0];
  const lat = loc[1];

  function initMap() {
    var uluru = { lat: lat, lng: lng };
    var map = new google.maps.Map(document.getElementById("map"), {
      zoom: 15,
      center: uluru
    });
    var marker = new google.maps.Marker({ position: uluru, map: map });
    map.addListener("click", function() {
      if (
        navigator.platform.indexOf("iPhone") != -1 ||
        navigator.platform.indexOf("iPod") != -1 ||
        navigator.platform.indexOf("iPad") != -1
      )
        window.open(
          `maps://www.google.com/maps/dir/?api=1&travelmode=driving&layer=traffic&destination=${lat},${lng}`
        );
      else
        window.open(
          `https://www.google.com/maps/dir/?api=1&travelmode=driving&layer=traffic&destination=${lat},${lng}`
        );
    });
  }
}

// =====

$(".boutiqua").fadeIn();
$(".nav-item").click(function() {
  if ($(this)[0].innerText === "Boutique") {
    $(".one").addClass("active");
    $(".tow").removeClass("active");
  }
  if ($(this)[0].innerText === "Offres") {
    $(".one").removeClass("active");
    $(".tow").addClass("active");
  }
});

$(".forum").hide();
$(".trier").click(function() {
  $(".there")[0].innerText = $(this)[0].innerText;
  $(".trier").hide();
  $(".forum").show();
});

$(".up").click(function() {
  $(".elem").attr("value", $(".there")[0].innerText + "1");
  $(".forum").submit();
});

$(".down").click(function() {
  $(".elem").attr("value", $(".there")[0].innerText + "2");
  $(".forum").submit();
});
