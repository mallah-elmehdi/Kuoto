$(function() {
  $('[data-toggle="tooltip"]').tooltip();
});

// =====

$(".three").hide();
$(".four").hide();
$(".car-delet").click(function() {
  for (var i = 0; i < $(".car-delet").length; i++) {
    $(".card-footer").removeClass("footer");
    $(".card-footer").addClass("footer-1");
    $(".two").hide();
    $(".one").hide();
    $(".three").show();
    $(".four").show();
  }
});

$(".x").click(function() {
  for (var i = 0; i < $(".x").length; i++) {
    var id = $(this).attr("id");
    $(".card-footer").removeClass("footer-1");
    $(".card-footer").addClass("footer");
    $(".three").hide();
    $(".four").hide();
    $(".two").show();
    $(".one").show();
  }
});

$(".remove").click(function() {
  for (var i = 0; i < $(".remove").length; i++) {
    var id = $(this).attr("id");
  }
});

// =====

var date = Date.now();

$(".savebar").hide();

$(".check").click(function() {
  $(".savebar").fadeIn();
  $(".fa-circle").toggleClass("green gray");
  if ($(".fa-circle").hasClass("green")) {
    $(".onOff").attr("value", `Oui at ${date}`);
  }
  if ($(".fa-circle").hasClass("gray")) {
    $(".onOff").attr("value", `Non at ${date}`);
  }
});

$(".close").click(function() {
  location.reload();
});

// =====

$(".the-body").fadeIn();
$(".carBox").hide();
$(".car-edit").click(function() {
  $(".savebar").hide();
  $(".carBox").fadeIn();
  $(".the-body").hide();
});

$(".anl").click(function() {
  $(".the-body").fadeIn();
  $(".carBox").hide();
});

// =====

const func = function() {
  $(".s").removeClass("tow-line");
  $(".fa-plus-square").addClass("fa-camera");
  $(".fa-plus-square").removeClass("fa-plus-square");
  $(".imgs-car").addClass("car-images");
  $(".imgs-car").removeClass("imgs-car");
  $(".remove").remove();
  $(".pip").remove();
};

$(document).ready(function() {
  if (window.File && window.FileList && window.FileReader) {
    $("#capics").on("change", function(e) {
      var files = e.target.files,
        filesLength = files.length;

      $(".fa-camera").addClass("fa-plus-square");
      $(".fa-camera").removeClass("fa-camera");
      $(".car-images").addClass("imgs-car");
      $(".s").addClass("tow-line");
      $(".car-images").removeClass("car-images");
      $('<i class="fas fa-times-circle float-right remove"></i>').insertAfter(
        ".fa-plus-square"
      );

      for (var i = 0; i < filesLength; i++) {
        var f = files[i];
        var fileReader = new FileReader();
        fileReader.onload = function(e) {
          var file = e.target;

          var text = `<div class="pip"> <img class="imageThumb" src="${e.target.result}" title=""${file.name}>  </div>`;
          $(text).insertAfter(".here");
          $(".remove").click(function() {
            func();
          });
          
          $("#capics").click(function() {
            func();
            $(".remove").remove();
            $(".pip").remove();
          });
        };
        fileReader.readAsDataURL(f);
      }
      if (filesLength === 0) {
        func();
      }
    });
  } else {
    alert("Your browser doesn't support to File API");
  }
});

// ======

$(window).on("load", function() {
  $(".sniper").fadeOut(500);
});